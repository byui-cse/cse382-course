-module(map_filter).

-export([]).
