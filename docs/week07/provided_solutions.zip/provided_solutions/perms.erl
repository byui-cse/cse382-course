%% @author Lee Barney
%% @copyright 2021 Lee Barney licensed under the <a>
%%        rel="license"
%%        href="http://creativecommons.org/licenses/by/4.0/"
%%        target="_blank">
%%        Creative Commons Attribution 4.0 International License</a>
%%
%%
%% These solutions are not intended to be ideal solutions. Instead,
%% they are solutions that you can compare against yours to see
%% other options and to come up with even better solutions.
%%
-module(perms).
-export([heaps_algo/3,swap/3]).


heaps_algo(1, Base,Accum)->
	[Base]++Accum;
heaps_algo(K,Base,Accum)->
	perms_for(K,1,heaps_algo(K-1,Base,Accum)).

perms_for(K,I,Accum) when K == I ->
	Accum;
perms_for(K,I,Accum) when K rem 2 == 0->
	[H|_] = Accum,
	perms_for(K,I+1,heaps_algo(K-1,swap(I,K,H),Accum));

perms_for(K,I,Accum)->
	[H|_] = Accum,
	perms_for(K,I+1,heaps_algo(K-1,swap(1,K,H),Accum)).


%Complexity O(n)
swap(A,B,List) when A == B; A == 0; B == 0->
	List;
swap(A, B, List) ->
    {P1, P2} = {min(A,B), max(A,B)},
    {L1, [Elem1 | T1]} = lists:split(P1-1, List),
    {L2, [Elem2 | L3]} = lists:split(P2-P1-1, T1), 
    lists:append([L1, [Elem2], L2, [Elem1], L3]).

