-module(actors_lazy).

-export([]).
