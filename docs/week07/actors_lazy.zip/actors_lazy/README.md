actors_lazy
=====

An OTP library

Build
-----

    $ rebar3 compile
