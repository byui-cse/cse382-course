bst_rbt
=====

An OTP library

Build
-----

    $ rebar3 compile
