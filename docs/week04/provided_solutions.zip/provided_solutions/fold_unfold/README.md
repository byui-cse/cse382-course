fold_unfold
=====

An OTP library

Build
-----

    $ rebar3 compile
