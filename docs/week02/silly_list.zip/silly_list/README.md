silly_list
=====

An OTP library

Build
-----

    $ rebar3 compile
