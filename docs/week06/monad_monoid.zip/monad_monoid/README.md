monad_monoid
=====

An OTP library

Build
-----

    $ rebar3 compile
