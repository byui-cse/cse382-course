-module(monad_monoid).

-export([]).
