%% @author Lee Barney
%% @copyright 2021 Lee Barney licensed under the <a>
%%        rel="license"
%%        href="http://creativecommons.org/licenses/by/4.0/"
%%        target="_blank">
%%        Creative Commons Attribution 4.0 International License</a>
%%
%%
%% These solutions are not intended to be ideal solutions. Instead,
%% they are solutions that you can compare against yours to see
%% other options and to come up with even better solutions.
%%

-module(task1).

id = [[],[]].

append([List,Other])->
	[List ++ Other,[]].

intersection([List,Other])->
	[x||x<-List, member(x,Other)],[]].

difference([List,Other])->
	[[x||x<-List, not member(x,Other)],[]].



member(_, []) -> false;
member(Value, [H|T]) -> 
  case H of
    Value -> true;
    _ -> member(T)
  end.

