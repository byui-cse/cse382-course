chain_curry_partial
=====

An OTP library

Build
-----

    $ rebar3 compile
