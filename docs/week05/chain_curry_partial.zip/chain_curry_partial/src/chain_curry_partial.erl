-module(chain_curry_partial).

-export([]).
